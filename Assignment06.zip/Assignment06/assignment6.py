#Chelsea Smith
#2/19/2018
#Assignment 6
#Note: I used my code from assignment 5 as a basis for the code within the methods and functions


#Data
objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
strTask = ""
strPriority = ""

#This function loads the initial information from the text file into a table
def LoadTable(FileName):
    objFile = open(FileName, "r")
    Table = []
    for line in objFile:
        Data = line.strip()
        Dummy = Data.split(',')
        dicRow = {"Task": Dummy[0], "Priority": Dummy[1]}
        Table.append(dicRow)
    objFile.close()
    return Table

#Using LoadTable
lstTable = LoadTable(objFileName)

#Processing
class ListManager(object):
    """This is a class to manage the to do list. A lot of the code in the methods"""
    @staticmethod
    def ShowList(Table):
        print("Task\t\tPriority")
        for row in Table:
            print(row["Task"] + "\t\t" + row["Priority"])

    @staticmethod
    def AddTask(Table):
        strTask = input("Enter Task:")
        strPriority = input("Enter Priority:")
        dicRow = {"Task": strTask, "Priority": strPriority}
        Table.append(dicRow)
        return Table

    @staticmethod
    def Removal(Table):
        strTask = input("Enter the name of the task to be deleted:")
        intTest = 0
        for x in range(len(Table)):
            if strTask == Table[x]["Task"]:
                intTest = 1
                Table.pop(x)
                print(strTask + " deleted successfully.")
                break
        if intTest == 0:
            print(strTask + " not found.")
        return Table

    @staticmethod
    def Save(Table, FileName):
        objFile = open(FileName, "w")
        for row in Table:
            objFile.write(row["Task"] + "," + row["Priority"] + "\n")
        objFile.close()

# The code for the while loop and the structure of the if statements is unchanged from assignment 5.
#Presentation
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if(strChoice.strip() == '1'):
        ListManager.ShowList(lstTable)
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        lstTable = ListManager.AddTask(lstTable)
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        lstTable = ListManager.Removal(lstTable)
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        ListManager.Save(lstTable, objFileName)
    elif (strChoice == '5'):
        break #and Exit the program
    else:
        print("Incorrect selection. Please enter a number between 1 and 5.")

