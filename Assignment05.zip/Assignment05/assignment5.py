#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Chelsea Smith, 2/12/18, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []
lstDummy = []
strTask = ""
strPriority = ""

# Step 1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"
objFile = open(objFileName, "r")
for line in objFile:
     strData = line.strip()
     lstDummy = strData.split(',')
     dicRow ={"Task":lstDummy[0], "Priority":lstDummy[1]}
     lstTable.append(dicRow)
objFile.close()

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Task\t\tPriority")
        for row in lstTable:
            print(row["Task"] + "\t\t" + row["Priority"])
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask = input("Enter Task:")
        strPriority = input("Enter Priority:")
        dicRow = {"Task":strTask, "Priority":strPriority}
        lstTable.append(dicRow)
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        strTask = input("Enter the name of the task to be deleted:")
        intTest = 0
        for x in range(len(lstTable)):
            if strTask == lstTable[x]["Task"]:
                intTest = 1
                lstTable.pop(x)
                print (strTask + "deleted successfully.")
        if intTest == 0:
            print (strTask + " not found.")
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        objFile = open(objFileName, "w")
        for row in lstTable:
            objFile.write(row["Task"] + "," + row["Priority"] + "\n")
        objFile.close()
        continue
    elif (strChoice == '5'):
        break #and Exit the program
    else:
        print("Incorrect selection. Please enter a number between 1 and 5.")

